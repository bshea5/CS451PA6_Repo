Author: Brandon Shea
PA6

1. The OS and compiler that you compile your code
Both Mac OSX and Windows 7. It will run with either Visual Studio 2013 or in terminal on mac/unix with ./raytracer env-2.rt

2. How to build your program
Make file or Build in Visual studio

3. Tasks that you completed
I did not render the rt file with the 2 spheres and the elephant, since they would take my computer entirely too long. Instead I produced my own rt file that has images for 1 and 10 rays. I also supplied 1,10, and 100 ray pictures for the rt file provided to us with the 3 boxes

4. Tasks that you started but did not complete
N/A

5. Tasks that you did not start
N/A

6. What are the known bugs in your code?
None

NOTES:
My rt file has 2 elephants and a box.
Could not render 100 rays per pixel for this file, but was able to for env-2.rt