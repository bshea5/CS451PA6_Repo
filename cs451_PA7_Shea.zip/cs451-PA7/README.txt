Author: Brandon Shea
CS451 PA7

1. The OS and compiler that you compile your code
Mac OSX and Windows 7. Can use visual studio or the make file to compile

2. How to build your program
Build in Visual Studio or with the make file
Uses the .rt file I included

3. Tasks that you completed
Mostly Completed all tasks I think.

4. Tasks that you started but did not complete
N/A

5. Tasks that you did not start
N/A

6. What are the known bugs in your code?
Had to put a box in the second .rt file to get the light right
Refraction isn't quite right as the image in the sphere isn't upside down.
Shadows still seem a little dark